function indexSubmit(pl) {
    document.indexForm.indice.value=pl;
    document.indexForm.submit();
}

function valideChoix(lg){
	if((document.palmaresFormHeader.periodeSelector.value!='JOUR')&&
	  (document.palmaresFormHeader.typeSelector.value=='CAPITJ')){
		if (lg=="es"){
			alert("Los rankings de efectivos est�n disponibles solo para de un d�a");
		}else if (lg=="en"){
			alert("Trade value ranking are available only for intraday period.");
		}else{
			alert("Les palmar�s capitaux ne sont disponibles que pour la p�riode Jour.");
		}
	}else{
		document.palmaresFormHeader.submit();
	}
}
             
             
function Submit_recherche(lg){
	var code = document.fininfo_menu.code_libelle.value;
	if ((code!='') && (code != 'undefined')){
		//document.fininfo_menu.action = url;
		document.fininfo_menu.submit();
	}else{
		if (lg=="es"){
			alert("Es necesario introducir un c�digo o un nombre");
		}else if (lg=="en"){
			alert("You have enter a code or a name");
		}else{
			alert("Vous devez saisir un code ou un libell�");
		}
	}
}

function Open_WindowOpcvm(url){

	choix = window.open("","Europerformance","height=600,width=790,resizable=yes,scrollbars=yes,toolbar=1,status=0");
	choix.close();
	//choix.name="europerformance_main";
	choix = window.open(url,"Europerformance","height=600,width=790,resizable=yes,scrollbars=yes,toolbar=1,status=0");
}

function emulateur(url) {
	//var url="http://www.fininfo.com.grp:8083/fininfo/EmulateurFininfo.html";
	choix = window.open("","Mobile","height=470,width=220,resizable=yes,scrollbars=yes,toolbar=1,status=0");
	choix.close();
	choix = window.open(url,"Mobile","height=470,width=220,resizable=yes,scrollbars=yes,toolbar=1,status=0");

}